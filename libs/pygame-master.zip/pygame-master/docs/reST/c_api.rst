*********
  C API
*********

pygame C API
============

.. toctree::
   :maxdepth: 1
   :glob:

   c_api/*

src_c/include/ contains header files for applications
that use the pygame C API, while src_c/ contains
headers used by pygame internally.
