.. include:: common.txt

:mod:`pygame.draw`
==================

.. module:: pygame.draw
   :synopsis: pygame module for drawing shapes

| :sl:`pygame module for drawing shapes`

Draw several simple shapes to a surface. These functions will work for
rendering to any format of surface. Rendering to hardware surfaces will be
slower than regular software surfaces.

Most of the functions take a width argument to represent the size of stroke
(thickness) around the edge of the shape. If a width of 0 is passed the shape
will be filled (solid).

All the drawing functions respect the clip area for the surface and will be
constrained to that area. The functions return a rectangle representing the
bounding area of changed pixels. This bounding rectangle is the 'minimum'
bounding box that encloses the affected area.

All the drawing functions accept a color argument that can be one of the
following formats:

   - a :mod:`pygame.Color` object
   - an ``(RGB)`` triplet (tuple/list)
   - an ``(RGBA)`` quadruplet (tuple/list)
   - an integer value that has been mapped to the surface's pixel format
     (see :func:`pygame.Surface.map_rgb` and :func:`pygame.Surface.unmap_rgb`)

A color's alpha value will be written directly into the surface (if the
surface contains pixel alphas), but the draw function will not draw
transparently.

These functions temporarily lock the surface they are operating on. Many
sequential drawing calls can be sped up by locking and unlocking the surface
object around the draw calls (see :func:`pygame.Surface.lock` and
:func:`pygame.Surface.unlock`).

.. function:: rect

   | :sl:`draw a rectangle`
   | :sg:`rect(surface, color, rect) -> Rect`
   | :sg:`rect(surface, color, rect, width=0) -> Rect`

   Draws a rectangle on the given surface.

   :param Surface surface: surface to draw on
   :param color: color to draw with, the alpha value is optional if using a
      tuple ``(RGB[A])``
   :type color: Color or int or tuple(int, int, int, [int])
   :param Rect rect: rectangle to draw, position and dimensions
   :param int width: (optional) used for line thickness or to indicate that
      the rectangle is to be filled (not to be confused with the width value
      of the ``rect`` parameter)

         | if ``width == 0``, (default) fill the rectangle
         | if ``width > 0``, used for line thickness
         | if ``width < 0``, nothing will be drawn
         |

         .. note::
            When using ``width`` values ``> 1``, the edge lines will grow
            outside the original boundary of the rect. For more details on
            how the thickness for edge lines grow, refer to the ``width`` notes
            for :func:`line`.

   :returns: a rect bounding the changed pixels, if nothing is drawn the
      bounding rect's position will be the position of the given ``rect``
      parameter and its width and height will be 0
   :rtype: Rect

   .. note::
      The :func:`pygame.Surface.fill()` method works just as well for drawing
      filled rectangles and can be hardware accelerated on some platforms with
      both software and hardware display modes.

   .. versionchanged:: 2.0.0 Added support for keyword arguments.

   .. ## pygame.draw.rect ##

.. function:: polygon

   | :sl:`draw a polygon`
   | :sg:`polygon(surface, color, points) -> Rect`
   | :sg:`polygon(surface, color, points, width=0) -> Rect`

   Draws a polygon on the given surface.

   :param Surface surface: surface to draw on
   :param color: color to draw with, the alpha value is optional if using a
      tuple ``(RGB[A])``
   :type color: Color or int or tuple(int, int, int, [int])
   :param points: a sequence of 3 or more (x, y) coordinates that make up the
      vertices of the polygon, each *coordinate* in the sequence must be a
      tuple/list/:class:`pygame.math.Vector2` of 2 ints/floats,
      e.g. ``[(x1, y1), (x2, y2), (x3, y3)]``
   :type points: tuple(coordinate) or list(coordinate)
   :param int width: (optional) used for line thickness or to indicate that
      the polygon is to be filled

         | if width == 0, (default) fill the polygon
         | if width > 0, used for line thickness
         | if width < 0, nothing will be drawn
         |

         .. note::
            When using ``width`` values ``> 1``, the edge lines will grow
            outside the original boundary of the polygon. For more details on
            how the thickness for edge lines grow, refer to the ``width`` notes
            for :func:`line`.

   :returns: a rect bounding the changed pixels, if nothing is drawn the
      bounding rect's position will be the position of the first point in the
      ``points`` parameter and its width and height will be 0
   :rtype: Rect

   :raises ValueError: if ``len(points) < 3`` (must have at least 3 points)
   :raises TypeError: if ``points`` is not a sequence or ``points`` does not
      contain number pairs

   .. note::
       For an aapolygon, use :func:`aalines()` with ``closed=True``.

   .. versionchanged:: 2.0.0 Added support for keyword arguments.

   .. ## pygame.draw.polygon ##

.. function:: circle

   | :sl:`draw a circle`
   | :sg:`circle(surface, color, center, radius) -> Rect`
   | :sg:`circle(surface, color, center, radius, width=0) -> Rect`

   Draws a circle on the given surface.

   :param Surface surface: surface to draw on
   :param color: color to draw with, the alpha value is optional if using a
      tuple ``(RGB[A])``
   :type color: Color or int or tuple(int, int, int, [int])
   :param center: center point of the circle as a sequence of 2 ints/floats,
      e.g. ``(x, y)``
   :type center: tuple(int or float, int or float) or
      list(int or float, int or float) or Vector2(int or float, int or float)
   :param int radius: radius of the circle, measured from the ``center``
      parameter, a radius of 0 will only draw the ``center`` pixel
   :param int width: (optional) used for line thickness or to indicate that
      the circle is to be filled

         | if ``width == 0``, (default) fill the circle
         | if ``width > 0``, used for line thickness
         | if ``width < 0``, raises a ``ValueError``
         |

         .. note::
            When using ``width`` values ``> 1``, the edge lines will only grow
            inward.

   :returns: a rect bounding the changed pixels, if nothing is drawn the
      bounding rect's position will be the ``center`` parameter value and its
      width and height will be 0
   :rtype: Rect

   :raises ValueError: if ``radius < 0`` or ``width < 0`` or ``width > radius``

   .. versionchanged:: 2.0.0 Added support for keyword arguments.

   .. ## pygame.draw.circle ##

.. function:: ellipse

   | :sl:`draw an ellipse`
   | :sg:`ellipse(surface, color, rect) -> Rect`
   | :sg:`ellipse(surface, color, rect, width=0) -> Rect`

   Draws an ellipse on the given surface.

   :param Surface surface: surface to draw on
   :param color: color to draw with, the alpha value is optional if using a
      tuple ``(RGB[A])``
   :type color: Color or int or tuple(int, int, int, [int])
   :param Rect rect: rectangle to indicate the position and dimensions of the
      ellipse, the ellipse will be centered inside the rectangle and bounded
      by it
   :param int width: (optional) used for line thickness or to indicate that
      the ellipse is to be filled (not to be confused with the width value
      of the ``rect`` parameter)

         | if ``width == 0``, (default) fill the ellipse
         | if ``width > 0``, used for line thickness
         | if ``width < 0``, raises a ``ValueError``
         |

         .. note::
            When using ``width`` values ``> 1``, the edge lines will only grow
            inward from the original boundary of the ``rect`` parameter.

   :returns: a rect bounding the changed pixels, if nothing is drawn the
      bounding rect's position will be the position of the given ``rect``
      parameter and its width and height will be 0
   :rtype: Rect

   :raises ValueError: if ``width < 0`` or ``width > rect.w / 2`` or
      ``width > rect.h / 2``

   .. versionchanged:: 2.0.0 Added support for keyword arguments.

   .. ## pygame.draw.ellipse ##

.. function:: arc

   | :sl:`draw an elliptical arc`
   | :sg:`arc(surface, color, rect, start_angle, stop_angle) -> Rect`
   | :sg:`arc(surface, color, rect, start_angle, stop_angle, width=1) -> Rect`

   Draws an elliptical arc on the given surface.

   The two angle arguments are given in radians and indicate the start and stop
   positions of the arc. The arc is drawn in a counterclockwise direction from
   the ``start_angle`` to the ``stop_angle``.

   :param Surface surface: surface to draw on
   :param color: color to draw with, the alpha value is optional if using a
      tuple ``(RGB[A])``
   :type color: Color or int or tuple(int, int, int, [int])
   :param Rect rect: rectangle to indicate the position and dimensions of the
      ellipse which the arc will be based on, the ellipse will be centered
      inside the rectangle
   :param float start_angle: start angle of the arc in radians
   :param float stop_angle: stop angle of the arc in
      radians

         | if ``start_angle < stop_angle``, the arc is drawn in a
            counterclockwise direction from the ``start_angle`` to the
            ``stop_angle``
         | if ``start_angle > stop_angle``, tau (tau == 2 * pi) will be added
            to the ``stop_angle``, if the resulting stop angle value is greater
            than the ``start_angle`` the above ``start_angle < stop_angle`` case
            applies, otherwise nothing will be drawn
         | if ``start_angle == stop_angle``, nothing will be drawn
         |

   :param int width: (optional) used for line thickness (not to be confused
      with the width value of the ``rect`` parameter)

         | if ``width == 0``, nothing will be drawn
         | if ``width > 0``, (default is 1) used for line thickness
         | if ``width < 0``, raises a ``ValueError``
         |

         .. note::
            When using ``width`` values ``> 1``, the edge lines will only grow
            inward from the original boundary of the ``rect`` parameter.

   :returns: a rect bounding the changed pixels, if nothing is drawn the
      bounding rect's position will be the position of the given ``rect``
   :rtype: Rect

   :raises ValueError: if ``width < 0`` or ``width > rect.w / 2`` or
      ``width > rect.h / 2``

   .. versionchanged:: 2.0.0 Added support for keyword arguments.

   .. ## pygame.draw.arc ##

.. function:: line

   | :sl:`draw a straight line`
   | :sg:`line(surface, color, start_pos, end_pos, width) -> Rect`
   | :sg:`line(surface, color, start_pos, end_pos, width=1) -> Rect`

   Draws a straight line on the given surface. There are no endcaps. For thick
   lines the ends are squared off.

   :param Surface surface: surface to draw on
   :param color: color to draw with, the alpha value is optional if using a
      tuple ``(RGB[A])``
   :type color: Color or int or tuple(int, int, int, [int])
   :param start_pos: start position of the line, (x, y)
   :type start_pos: tuple(int or float, int or float) or
      list(int or float, int or float) or Vector2(int or float, int or float)
   :param end_pos: end position of the line, (x, y)
   :type end_pos: tuple(int or float, int or float) or
      list(int or float, int or float) or Vector2(int or float, int or float)
   :param int width: (optional) used for line thickness

         | if width >= 1, used for line thickness (default is 1)
         | if width < 1, nothing will be drawn
         |

         .. note::
            When using ``width`` values ``> 1`` lines will grow as follows.

            For odd ``width`` values, the thickness of each line grows with the
            original line being in the center.

            For even ``width`` values, the thickness of each line grows with the
            original line being offset from the center (as there is no exact
            center line drawn). As a result, lines with a slope < 1
            (horizontal-ish) will have 1 more pixel of thickness below the
            original line (in the y direction). Lines with a slope >= 1
            (vertical-ish) will have 1 more pixel of thickness to the right of
            the original line (in the x direction).

   :returns: a rect bounding the changed pixels, if nothing is drawn the
      bounding rect's position will be the ``start_pos`` parameter (float values
      will be truncated) and its width and height will be 0
   :rtype: Rect

   :raises TypeError: if ``start_pos`` or ``end_pos`` is not a sequence of
      two numbers

   .. versionchanged:: 2.0.0 Added support for keyword arguments.

   .. ## pygame.draw.line ##

.. function:: lines

   | :sl:`draw multiple contiguous line segments`
   | :sg:`lines(Surface, color, closed, pointlist, width=1) -> Rect`

   Draw a sequence of lines on a Surface. The pointlist argument is a series of
   points that are connected by a line. If the closed argument is true an
   additional line segment is drawn between the first and last points.

   This does not draw any endcaps or miter joints. Lines with sharp corners and
   wide line widths can have improper looking corners.

   .. ## pygame.draw.lines ##

.. function:: aaline

   | :sl:`draw a straight antialiased line`
   | :sg:`aaline(surface, color, start_pos, end_pos) -> Rect`
   | :sg:`aaline(surface, color, start_pos, end_pos, blend=1) -> Rect`

   Draws a straight antialiased line on the given surface.

   :param Surface surface: surface to draw on
   :param color: color to draw with, the alpha value is optional if using a
      tuple ``(RGB[A])``
   :type color: Color or int or tuple(int, int, int, [int])
   :param start_pos: start position of the line, (x, y)
   :type start_pos: tuple(int or float, int or float) or
      list(int or float, int or float) or Vector2(int or float, int or float)
   :param end_pos: end position of the line, (x, y)
   :type end_pos: tuple(int or float, int or float) or
      list(int or float, int or float) or Vector2(int or float, int or float)
   :param int blend: (optional) if non-zero (default) the line will be blended
      with the surface's existing pixel shades, otherwise it will overwrite them

   :returns: a rect bounding the changed pixels, if nothing is drawn the
      bounding rect's position will be the ``start_pos`` parameter (float values
      will be truncated) and its width and height will be 0
   :rtype: Rect

   :raises TypeError: if ``start_pos`` or ``end_pos`` is not a sequence of
      two numbers

   .. versionchanged:: 2.0.0 Added support for keyword arguments.

   .. ## pygame.draw.aaline ##

.. function:: aalines

   | :sl:`draw a connected sequence of antialiased lines`
   | :sg:`aalines(Surface, color, closed, pointlist, blend=1) -> Rect`

   Draws a sequence on a surface. You must pass at least two points in the
   sequence of points. The closed argument is a simple Boolean and if true, a
   line will be draw between the first and last points. The Boolean blend
   argument set to true will blend the shades with existing shades instead of
   overwriting them. This function accepts floating point values for the end
   points.

   .. ## pygame.draw.aalines ##

.. ## pygame.draw ##

.. figure:: code_examples/draw_module_example.png
   :scale: 50 %
   :alt: draw module example

   Example code for draw module.

.. literalinclude:: code_examples/draw_module_example.py

